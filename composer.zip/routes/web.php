<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PacienteController;
use App\Http\Controllers\MotivoConsultaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminUserController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});
Route::middleware(['auth','is_admin'])->prefix('admin')->group(function(){
    Route::get('/usuarios/index', [AdminUserController::class, 'index'])->name('admin.usuarios');
    Route::get('/usuarios/create', [AdminUserController::class, 'create'])->name('admin.usuarios.create');
    Route::post('/usuarios', [AdminUserController::class, 'store'])->name('admin.usuarios.store');
    Route::get('/usuarios/{id}/edit', [AdminUserController::class, 'edit'])->name('admin.usuarios.edit');
    Route::put('/usuarios/{id}', [AdminUserController::class, 'update'])->name('admin.usuarios.update');
    Route::delete('/usuarios/{id}', [AdminUserController::class, 'destroy'])->name('admin.usuarios.destroy');



});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');

    // Pacientes
    Route::get('/pacientes', [PacienteController::class, 'index'])->name('pacientes.index');
    Route::get('/pacientes/create', [PacienteController::class, 'create'])->name('pacientes.create');
    Route::post('/pacientes', [PacienteController::class, 'store'])->name('pacientes.store');
    Route::get('/pacientes/{identidad}/historial', [PacienteController::class, 'historial'])->name('pacientes.historial');
    Route::get('/pacientes/buscar', [PacienteController::class, 'buscar'])->name('pacientes.buscar');

    // Consultas
    Route::post('/consultas', [MotivoConsultaController::class, 'store'])->name('consultas.store');
    Route::put('/pacientes/actualizar/{identidad}', [PacienteController::class, 'updatePorIdentidad'])
        ->where('identidad', '[A-Za-z0-9\-]+') // acepta letras, números y guiones
        ->name('pacientes.update');


});

require __DIR__.'/auth.php';
