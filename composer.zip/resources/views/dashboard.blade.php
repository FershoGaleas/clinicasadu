<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-xxl-center text-dark-emphasis">
            Bienvenido
        </h2>
    </x-slot>

    <div class="d-flex justify-content-center align-items-center min-vh-100" style="background-color: #ffffff;">
        <div class="row justify-content-center mb-5">
            <div class="col-md-12 mb-7">
                <a href="{{ route('pacientes.index') }}" class="btn btn-lg w-100 py-4 text-white shadow-sm"
                   style="background: linear-gradient(135deg, #4e73df, #224abe); border-radius: 12px; font-size: 1.2rem; transition: transform 0.2s ease;">
                    📋 Ver listado de pacientes
                </a>
            </div>
            <div class="col-md-12 mb-3">
                <a href="{{ route('pacientes.create') }}" class="btn btn-lg w-100 py-4 text-white shadow-sm"
                   style="background: linear-gradient(135deg, #1cc88a, #17a673); border-radius: 12px; font-size: 1.2rem; transition: transform 0.2s ease;">
                    ➕ Registrar nuevo paciente
                </a>
            </div>
        </div>

        <style>
            a.btn:hover {
                transform: scale(1.03);
                box-shadow: 0 0 15px rgba(0,0,0,0.2);
            }
        </style>
    </div>
</x-app-layout>
