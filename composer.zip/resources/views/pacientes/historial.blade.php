<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xxl-center" style="max-width: 100%;text-align: center;">
            HISTORIAL DE PACIENTE
        </h2>
    </x-slot>
    <div x-data="{ edit: false }" class="p-4 bg-white rounded shadow" style="background-color: white;">
        <div class="flex justify-between items-center mb-4">
            <hr>

            <button @click="edit = !edit" class="btn btn-sm btn-primary">
                <span x-show="!edit">Editar</span>
                <span x-show="edit">Cancelar</span>
            </button>
        </div>
        <div class="d-flex justify-content-center align-items-center min-vh-50" style="background-color: #ffffff;">
            <div class="w-75" style="max-width: 90%;">
                <form x-show="edit" action="{{ route('pacientes.update', $paciente->identidad) }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label class="form-label">Nombre completo</label>
                        <input type="text" name="nombre_completo" class="form-control" value="{{ $paciente->nombre_completo }}">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">DNI</label>
                        <input type="text" name="identidad" class="form-control" value="{{ $paciente->identidad }}" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Fecha de nacimiento</label>
                        <input type="date" name="fecha_nacimiento" class="form-control" value="{{ $paciente->fecha_nacimiento }}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Dirección</label>
                        <textarea name="direccion" class="form-control mb-2">{{$paciente->direccion}}</textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Teléfono</label>
                        <input type="text" name="telefono" class="form-control" value="{{ $paciente->telefono }}">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Religión</label>
                        <input type="text" name="religion" class="form-control" value="{{ $paciente->religion }}">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Edad</label>
                        <input type="number" name="edad" class="form-control" value="{{ $paciente->edad }}">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Sexo</label>
                        <select name="sexo" class="form-control">
                            <option value="1" {{ $paciente->sexo == 1 ? 'selected' : '' }}>Masculino</option>
                            <option value="2" {{ $paciente->sexo == 2 ? 'selected' : '' }}>Femenino</option>
                            <option value="0" {{ $paciente->sexo == 0 ? 'selected' : '' }}>No definido</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success">Guardar cambios</button>
                </form>

                <!-- Vista solo lectura -->
                <div x-show="!edit">
                    <p style="font-size: 20px;"><strong>Nombre:</strong> {{ $paciente->nombre_completo }}</p>
                    <p style="font-size: 20px;"><strong>DNI:</strong> {{ $paciente->identidad }}</p>
                    <p style="font-size: 20px;"><strong>Fecha de nacimiento:</strong> {{ $paciente->fecha_nacimiento }}</p>
                    <p style="font-size: 20px;"><strong>Dirección:</strong> {{ $paciente->direccion }}</p>
                    <p style="font-size: 20px;"><strong>Teléfono:</strong> {{ $paciente->telefono }}</p>
                    <p style="font-size: 20px;"><strong>Religión:</strong> {{ $paciente->religion }}</p>
                    <p style="font-size: 20px;"><strong>Edad:</strong> {{ $paciente->edad }}</p>
                    <p style="font-size: 20px;"><strong>Sexo:</strong>
                        @if($paciente->sexo == 1)
                            Masculino
                        @elseif($paciente->sexo == 2)
                            Femenino
                        @else
                            No definido
                        @endif
                    </p>
                </div>
            </div>
        </div>

    </div>
    <div style="width: 100%;" class="d-flex justify-content-center align-items-center">
        <table class="table table-bordered mt-4" style="background-color: white; width: 98%;">
            <thead class="table-dark">
            <tr>
                <th>Fecha</th>
                <th>Motivo</th>
                <th>Diagnóstico</th>
                <th>Tratamiento</th>
                <th>Examenes</th>
                <th>Medico</th>
                <th>Próxima cita</th>
            </tr>
            </thead>
            <tbody>
            @forelse($paciente->consultas as $consulta)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($consulta->fecha_actual)->format('d/m/Y H:i') }}</td>
                    <td>{{ $consulta->descripcion_motivo }}</td>
                    <td>{{ $consulta->diagnostico }}</td>
                    <td>{{ $consulta->tratamiento }}</td>
                    <td>{{ $consulta->examenes }}</td>
                    <td>{{ $consulta->nombre_medico }}</td>
                    <td>{{ $consulta->fecha_siguiente_cita ? \Carbon\Carbon::parse($consulta->fecha_siguiente_cita)->format('d/m/Y') : 'Sin cita' }}</td>

                </tr>
            @empty
                <tr>
                    <td colspan="9" class="text-center">No hay consultas registradas.</td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-center align-items-center min-vh-100" style="background-color: #ffffff;">
        <div class="w-75" style="max-width: 90%;">
            <hr>
            <h4>Agregar nueva consulta</h4>

            <form action="{{ route('consultas.store') }}" method="POST">
                @csrf
                <input type="hidden" name="identidad" value="{{ $paciente->identidad }}">
                <textarea name="antecedentes" class="form-control mb-2" placeholder="A.P.P..."></textarea>
                <textarea name="descripcion_motivo" class="form-control mb-2" placeholder="Motivo de consulta..."></textarea>
                <textarea name="historia_enfermedad_Actual" class="form-control mb-2" placeholder="HEA..."></textarea>
                <textarea name="diagnostico" class="form-control mb-2" placeholder="Diagnóstico..."></textarea>
                <textarea name="tratamiento" class="form-control mb-2" placeholder="Tratamiento..."></textarea>
                <textarea name="examenes" class="form-control mb-2" placeholder="Exámenes..."></textarea>


                <div class="mb-3">
                    <label for="fecha_siguiente_cita" class="form-label">Fecha Proxima Cita</label>
                    <input type="date" name="fecha_siguiente_cita" class="form-control mb-3">
                    @error('fecha_siguiente_cita') <small class="text-danger">{{ $message }}</small> @enderror
                </div>
                <div class="mb-3">
                    <label for="nombre_medico" class="form-label">Nombre de medico que realizo consulta</label>
                    <input type="text" name="nombre_medico" class="form-control" value="{{ old('nombre_medico') }}">
                    @error('nombre_medico') <small class="text-danger">{{ $message }}</small> @enderror
                </div>
                <button type="submit" class="btn btn-success">Guardar Consulta</button>
            </form>

        </div>
    </div>



</x-app-layout>


