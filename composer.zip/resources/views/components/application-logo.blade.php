<img src="{{ asset('build/assets/medicina_logo.png') }}" alt="Logo" class="h-25 w-auto">
