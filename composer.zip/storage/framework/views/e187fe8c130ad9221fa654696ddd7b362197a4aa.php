 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xxl-center">
                LISTADO DE PACIENTES
            </h2>
         <?php $__env->endSlot(); ?>
     <div class="d-flex justify-content-center pt-9 min-vh-100" style="background-color: #ffffff;">
        <div class="container md-8 mt-5" style="background-color: #ffffff;">

            <form action="<?php echo e(route('pacientes.buscar')); ?>" method="GET" class="row g-3 mt-0">
                <div class="col-md-4">
                    <input type="text" name="identidad" class="form-control" placeholder="Buscar por identidad" value="<?php echo e(request('identidad')); ?>">
                </div>
                <div class="col-md-4">
                    <input type="text" name="nombre" class="form-control" placeholder="Buscar por nombre" value="<?php echo e(request('nombre')); ?>">
                </div>

                <div class="col-md-3">
                    <select name="sexo" class="form-select">
                        <option value="">Sexo</option>
                        <option value="1" <?php echo e(request('sexo') == '1' ? 'selected' : ''); ?>>Masculino</option>
                        <option value="2" <?php echo e(request('sexo') == '2' ? 'selected' : ''); ?>>Femenino</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Buscar</button>
                </div>
            </form>

            <table class="table table-striped mt-4">
                <thead class="table-dark">
                <tr>
                    <th>DNI</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Edad</th>
                    <th>Sexo</th>
                    <th>Fecha de nacimiento</th>
                    <th>Historial</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($paciente->identidad); ?></td>
                        <td><?php echo e($paciente->nombre_completo); ?></td>
                        <td><?php echo e($paciente->telefono); ?></td>
                        <td><?php echo e($paciente->edad); ?></td>
                        <td><?php echo e($paciente->sexo == 1 ? 'Masculino' : 'Femenino'); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($paciente->fecha_nacimiento)->format('d/m/Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('pacientes.historial', $paciente->identidad)); ?>" class="btn btn-sm btn-info">VER</a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center">No se encontraron pacientes.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo e($pacientes->links()); ?>

            </div>
        </div>
     </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>




<?php /**PATH C:\Users\fgale\PhpstormProjects\FarmaciaAhorro\resources\views/pacientes/index.blade.php ENDPATH**/ ?>