<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xxl-center" style="max-width: 100%;text-align: center;">
            HISTORIAL DE PACIENTE
        </h2>
     <?php $__env->endSlot(); ?>
    <div x-data="{ edit: false }" class="p-4 bg-white rounded shadow" style="background-color: white;">
        <div class="flex justify-between items-center mb-4">
            <hr>

            <button @click="edit = !edit" class="btn btn-sm btn-primary">
                <span x-show="!edit">Editar</span>
                <span x-show="edit">Cancelar</span>
            </button>
        </div>
        <div class="d-flex justify-content-center align-items-center min-vh-50" style="background-color: #ffffff;">
            <div class="w-75" style="max-width: 90%;">
                <form x-show="edit" action="<?php echo e(route('pacientes.update', $paciente->identidad)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label">Nombre completo</label>
                        <input type="text" name="nombre_completo" class="form-control" value="<?php echo e($paciente->nombre_completo); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">DNI</label>
                        <input type="text" name="identidad" class="form-control" value="<?php echo e($paciente->identidad); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Fecha de nacimiento</label>
                        <input type="date" name="fecha_nacimiento" class="form-control" value="<?php echo e($paciente->fecha_nacimiento); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Dirección</label>
                        <textarea name="direccion" class="form-control mb-2"><?php echo e($paciente->direccion); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Teléfono</label>
                        <input type="text" name="telefono" class="form-control" value="<?php echo e($paciente->telefono); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Religión</label>
                        <input type="text" name="religion" class="form-control" value="<?php echo e($paciente->religion); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Edad</label>
                        <input type="number" name="edad" class="form-control" value="<?php echo e($paciente->edad); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Sexo</label>
                        <select name="sexo" class="form-control">
                            <option value="1" <?php echo e($paciente->sexo == 1 ? 'selected' : ''); ?>>Masculino</option>
                            <option value="2" <?php echo e($paciente->sexo == 2 ? 'selected' : ''); ?>>Femenino</option>
                            <option value="0" <?php echo e($paciente->sexo == 0 ? 'selected' : ''); ?>>No definido</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success">Guardar cambios</button>
                </form>

                <!-- Vista solo lectura -->
                <div x-show="!edit">
                    <p style="font-size: 20px;"><strong>Nombre:</strong> <?php echo e($paciente->nombre_completo); ?></p>
                    <p style="font-size: 20px;"><strong>DNI:</strong> <?php echo e($paciente->identidad); ?></p>
                    <p style="font-size: 20px;"><strong>Fecha de nacimiento:</strong> <?php echo e($paciente->fecha_nacimiento); ?></p>
                    <p style="font-size: 20px;"><strong>Dirección:</strong> <?php echo e($paciente->direccion); ?></p>
                    <p style="font-size: 20px;"><strong>Teléfono:</strong> <?php echo e($paciente->telefono); ?></p>
                    <p style="font-size: 20px;"><strong>Religión:</strong> <?php echo e($paciente->religion); ?></p>
                    <p style="font-size: 20px;"><strong>Edad:</strong> <?php echo e($paciente->edad); ?></p>
                    <p style="font-size: 20px;"><strong>Sexo:</strong>
                        <?php if($paciente->sexo == 1): ?>
                            Masculino
                        <?php elseif($paciente->sexo == 2): ?>
                            Femenino
                        <?php else: ?>
                            No definido
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

    </div>
    <div style="width: 100%;" class="d-flex justify-content-center align-items-center">
        <table class="table table-bordered mt-4" style="background-color: white; width: 98%;">
            <thead class="table-dark">
            <tr>
                <th>Fecha</th>
                <th>Motivo</th>
                <th>Diagnóstico</th>
                <th>Tratamiento</th>
                <th>Examenes</th>
                <th>Medico</th>
                <th>Próxima cita</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $paciente->consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($consulta->fecha_actual)->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($consulta->descripcion_motivo); ?></td>
                    <td><?php echo e($consulta->diagnostico); ?></td>
                    <td><?php echo e($consulta->tratamiento); ?></td>
                    <td><?php echo e($consulta->examenes); ?></td>
                    <td><?php echo e($consulta->nombre_medico); ?></td>
                    <td><?php echo e($consulta->fecha_siguiente_cita ? \Carbon\Carbon::parse($consulta->fecha_siguiente_cita)->format('d/m/Y') : 'Sin cita'); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">No hay consultas registradas.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-center align-items-center min-vh-100" style="background-color: #ffffff;">
        <div class="w-75" style="max-width: 90%;">
            <hr>
            <h4>Agregar nueva consulta</h4>

            <form action="<?php echo e(route('consultas.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="identidad" value="<?php echo e($paciente->identidad); ?>">
                <textarea name="antecedentes" class="form-control mb-2" placeholder="A.P.P..."></textarea>
                <textarea name="descripcion_motivo" class="form-control mb-2" placeholder="Motivo de consulta..."></textarea>
                <textarea name="historia_enfermedad_Actual" class="form-control mb-2" placeholder="HEA..."></textarea>
                <textarea name="diagnostico" class="form-control mb-2" placeholder="Diagnóstico..."></textarea>
                <textarea name="tratamiento" class="form-control mb-2" placeholder="Tratamiento..."></textarea>
                <textarea name="examenes" class="form-control mb-2" placeholder="Exámenes..."></textarea>


                <div class="mb-3">
                    <label for="fecha_siguiente_cita" class="form-label">Fecha Proxima Cita</label>
                    <input type="date" name="fecha_siguiente_cita" class="form-control mb-3">
                    <?php $__errorArgs = ['fecha_siguiente_cita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="nombre_medico" class="form-label">Nombre de medico que realizo consulta</label>
                    <input type="text" name="nombre_medico" class="form-control" value="<?php echo e(old('nombre_medico')); ?>">
                    <?php $__errorArgs = ['nombre_medico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-success">Guardar Consulta</button>
            </form>

        </div>
    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\Users\fgale\PhpstormProjects\FarmaciaAhorro\resources\views/pacientes/historial.blade.php ENDPATH**/ ?>