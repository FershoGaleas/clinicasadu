<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-xxl-center text-dark-emphasis">
            Bienvenido
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-center align-items-center min-vh-100" style="background-color: #ffffff;">
        <div class="row justify-content-center mb-5">
            <div class="col-md-12 mb-7">
                <a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-lg w-100 py-4 text-white shadow-sm"
                   style="background: linear-gradient(135deg, #4e73df, #224abe); border-radius: 12px; font-size: 1.2rem; transition: transform 0.2s ease;">
                    📋 Ver listado de pacientes
                </a>
            </div>
            <div class="col-md-12 mb-3">
                <a href="<?php echo e(route('pacientes.create')); ?>" class="btn btn-lg w-100 py-4 text-white shadow-sm"
                   style="background: linear-gradient(135deg, #1cc88a, #17a673); border-radius: 12px; font-size: 1.2rem; transition: transform 0.2s ease;">
                    ➕ Registrar nuevo paciente
                </a>
            </div>
        </div>

        <style>
            a.btn:hover {
                transform: scale(1.03);
                box-shadow: 0 0 15px rgba(0,0,0,0.2);
            }
        </style>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\fgale\PhpstormProjects\FarmaciaAhorro\resources\views/dashboard.blade.php ENDPATH**/ ?>