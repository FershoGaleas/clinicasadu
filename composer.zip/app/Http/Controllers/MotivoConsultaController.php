<?php

namespace App\Http\Controllers;

use App\Models\MotivoConsulta;
use Illuminate\Http\Request;

class MotivoConsultaController extends Controller
{
    //
    public function store(Request $request)
    {
        $request->validate([
            'identidad' => 'required|exists:pacientes,identidad',
            'nombre_medico' => 'nullable|string',
            'descripcion_motivo' => 'required|string',
            'historia_enfermedad_Actual' => 'nullable|string',
            'diagnostico' => 'nullable|string',
            'tratamiento' => 'nullable|string',
            'examenes' => 'nullable|string',
            'antecedentes' => 'nullable|string',
            'fecha_siguiente_cita' => 'nullable|date|after_or_equal:today'
        ]);

        MotivoConsulta::create($request->all());

        return redirect()->route('pacientes.historial', $request->identidad)->with('success', 'Consulta registrada correctamente.');
    }
}
