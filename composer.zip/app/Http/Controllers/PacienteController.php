<?php

namespace App\Http\Controllers;

use App\Models\MotivoConsulta;
use App\Models\Paciente;
use Illuminate\Http\Request;

class PacienteController extends Controller
{
    public function updatePorIdentidad(Request $request, $identidad)
    {


        $paciente = Paciente::where('identidad', $identidad)->firstOrFail();
        $paciente->update($request->all());

        return redirect()->back()->with('success', 'Datos actualizados correctamente');
    }


    public function historial($identidad)
    {
        $paciente = Paciente::where('identidad', $identidad)->with('consultas')->firstOrFail();
        return view('pacientes.historial', compact('paciente'));
    }

    public function index(){
        $pacientes = Paciente::paginate(10);
        return view('pacientes.index', compact('pacientes'));
    }
    public function buscar(Request $request)
    {
        $query = Paciente::query();
        if ($request->filled('identidad')) {
            $query->where('identidad', 'like', '%' . $request->identidad . '%');
        }
        if ($request->filled('nombre')) {
            $query->where('nombre_completo', 'like', '%' . $request->nombre . '%');
        }

        if ($request->filled('telefono')) {
            $query->where('telefono', 'like', '%' . $request->telefono . '%');
        }

        if ($request->filled('sexo')) {
            $query->where('sexo', $request->sexo);
        }

        $pacientes = $query->paginate(10);
        return view('pacientes.index', compact('pacientes'));
    }


    //mostrar formulario
    public function create(){
        return view('pacientes.create');
    }

    //guardar paciente en la bbdd
    public function store(Request $request){

        $request->validate([
            'identidad' => 'required|string|max:20',
           'nombre_completo' => 'required|string|max:100',
           'fecha_nacimiento' => 'required|date|before:today',
            'direccion' => 'required|string|max:200',
            'telefono' => 'required|string|max:20',
            'religion' => 'nullable|string|max:50',
            'edad' => 'required|integer|min:0',
            'sexo' => 'required|in:1,2',
            'descripcion_motivo' => 'required|string|max:255',
            'historia_enfermedad_Actual' => 'nullable|string|max:1000',
            'diagnostico' => 'nullable|string|max:1000',
            'tratamiento' => 'nullable|string|max:1000',
            'examenes' => 'nullable|string|max:1000',
            'antecedentes' => 'nullable|string|max:1000',
            'fecha_siguiente_cita' => 'nullable|date|after_or_equal:today'

        ]);

        $paciente = Paciente::create([
            'identidad' => $request->identidad,
            'nombre_completo' => $request->nombre_completo,
            'fecha_nacimiento' => $request->fecha_nacimiento,
            'direccion' => $request->direccion,
            'telefono' => $request->telefono,
            'religion' => $request->religion,
            'edad' => $request->edad,
            'sexo' => $request->sexo

        ]);

        //voy a guardar motivo de consulta vinculado al paciente
        MotivoConsulta::create([
            'identidad' => $paciente->identidad,
            'nombre_medico' => $request->nombre_medico,
            'descripcion_motivo' => $request->descripcion_motivo,
            'historia_enfermedad_Actual' => $request->historia_enfermedad_Actual,
            'diagnostico' => $request->diagnostico,
            'tratamiento' => $request->tratamiento,
            'examenes' => $request->examenes,
            'antecedentes' => $request->antecedentes,
            'fecha_siguiente_cita' => $request->fecha_siguiente_cita
        ]);

        return redirect()->route('pacientes.create')-> with('success','Paciente y consulta registrados correctamente');


    }
}
