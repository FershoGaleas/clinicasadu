<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pacientes extends Model
{
    use HasFactory;
    protected $fillable = [
       'identidad',
      'nombre_completo',
      'fecha_nacimiento',
        'direccion',
        'telefono',
        'religion',
      'edad',
      'sexo'
    ];
    public function consultas()
    {
        return $this->hasMany(MotivoConsulta::class, 'identidad', 'identidad');
    }

    public function apps(){
        return $this->hasMany(App::class, 'identidad');

    }
}

