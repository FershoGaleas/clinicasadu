<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Paciente extends Model
{
    use HasFactory;
    protected $primaryKey = 'id_paciente';
    protected $fillable = [
        'identidad',
        'nombre_completo',
        'fecha_nacimiento',
        'direccion',
        'telefono',
        'religion',
        'edad',
        'sexo'
    ];

    public function consultas()
    {
        return $this->hasMany(MotivoConsulta::class, 'identidad', 'identidad');
    }

    public function apps()
    {
        return $this->hasMany(App::class, 'identidad');

    }

    public function motivoconsulta()
    {
        return $this->hasOne(MotivoConsulta::class, 'identidad');
    }




}
