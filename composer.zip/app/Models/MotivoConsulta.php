<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MotivoConsulta extends Model
{
    use HasFactory;
    protected $fillable = [
        'identidad',
        'nombre_medico',
        'descripcion_motivo',
        'historia_enfermedad_Actual',
        'diagnostico',
        'tratamiento',
        'examenes',
        'antecedentes',
        'fecha_siguiente_cita'

    ];

    public function paciente()
    {
        return $this->belongsTo(Paciente::class, 'identidad', 'identidad');

    }

}
